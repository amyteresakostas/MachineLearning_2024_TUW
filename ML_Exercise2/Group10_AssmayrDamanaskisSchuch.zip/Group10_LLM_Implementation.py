import numpy as np
import pandas as pd
import time
import os
from sklearn.model_selection import KFold
from concurrent.futures import ProcessPoolExecutor

# Step 1: Define a function to split the dataset
def split_data(X, y, feature_index, threshold):
    left_mask = X.iloc[:, feature_index] <= threshold
    right_mask = ~left_mask
    return X[left_mask], y[left_mask], X[right_mask], y[right_mask]

# Step 2: Define the mean squared error (MSE) to evaluate splits
def mse(y):
    return np.mean((y - np.mean(y))**2) if len(y) > 0 else 0

def mse_split(y_left, y_right):
    n_left, n_right = len(y_left), len(y_right)
    n_total = n_left + n_right
    return (n_left / n_total) * mse(y_left) + (n_right / n_total) * mse(y_right)

# Step 3: Build a decision tree
class DecisionTreeRegressor:
    def __init__(self, max_depth=5, min_samples_split=2):
        self.max_depth = max_depth #The maximum depth of each decision tree.
        self.min_samples_split = min_samples_split #The minimum number of samples required to split a node.
        self.tree = None

    def fit(self, X, y, depth=0):
        # Stop conditions: max depth or too few samples
        if depth >= self.max_depth or len(y) < self.min_samples_split:
            return np.mean(y)

        # Find the best split
        best_feature, best_threshold, best_mse = None, None, float("inf")
        for feature_index in range(X.shape[1]):  # Loop over features
            thresholds = np.unique(X.iloc[:, feature_index])  # Get unique values for thresholds
            for threshold in thresholds:
                X_left, y_left, X_right, y_right = split_data(X, y, feature_index, threshold)
                if len(y_left) == 0 or len(y_right) == 0:
                    continue

                current_mse = mse_split(y_left, y_right)
                if current_mse < best_mse:
                    best_feature = feature_index
                    best_threshold = threshold
                    best_mse = current_mse

        # Stop if no split improves MSE
        if best_feature is None:
            return np.mean(y)

        # Split data and recurse
        X_left, y_left, X_right, y_right = split_data(X, y, best_feature, best_threshold)
        return {
            'feature': best_feature,
            'threshold': best_threshold,
            'left': self.fit(X_left, y_left, depth + 1),
            'right': self.fit(X_right, y_right, depth + 1),
        }

    def predict_one(self, tree, x):
        if not isinstance(tree, dict):
            return tree
        feature = tree['feature']
        threshold = tree['threshold']
        if x.iloc[feature] <= threshold:
            return self.predict_one(tree['left'], x)
        else:
            return self.predict_one(tree['right'], x)

    def predict(self, X):
        return np.array([self.predict_one(self.tree, x) for _, x in X.iterrows()])


# Step 4: Define the Random Forest Regressor
class RandomForestRegressor:
    def __init__(self, n_estimators=10, max_depth=5, min_samples_split=2, max_features=None):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.trees = []

    def bootstrap_sample(self, X, y):
        n_samples = X.shape[0]
        indices = np.random.choice(n_samples, n_samples, replace=True)
        return X.iloc[indices], y.iloc[indices]

    def train_tree(self, i, X, y):
        """Helper function to train a single tree."""
        print(f"Starting tree {i + 1} out of {self.n_estimators}...")
        start_time = time.time()

        # Bootstrap sampling
        X_sample, y_sample = self.bootstrap_sample(X, y)

        # Random feature selection
        max_features = self.max_features or X.shape[1]
        features = np.random.choice(range(X.shape[1]), max_features, replace=False)

        # Train a decision tree on the sampled dataset
        tree = DecisionTreeRegressor(max_depth=self.max_depth, min_samples_split=self.min_samples_split)
        X_sample_subset = X_sample.iloc[:, features]
        tree.tree = tree.fit(X_sample_subset, y_sample)

        elapsed_time = time.time() - start_time
        print(f"Finished tree {i + 1}. Time taken: {elapsed_time:.2f} seconds.")

        return tree, features

    def fit(self, X, y):
        self.trees = []

        # Parallelize tree training
        with ProcessPoolExecutor() as executor:
            tasks = [executor.submit(self.train_tree, i, X, y) for i in range(self.n_estimators)]
            for future in tasks:
                tree, features = future.result()
                self.trees.append((tree, features))

    def predict(self, X):
        predictions = []
        for tree, features in self.trees:
            X_subset = X.iloc[:, features]
            predictions.append(tree.predict(X_subset))
        return np.mean(predictions, axis=0)

""" WITHOUT PARALLELISM 
class RandomForestRegressor:
    def __init__(self, n_estimators=10, max_depth=5, min_samples_split=2, max_features=None):
        self.n_estimators = n_estimators #The number of decision trees in the forest
        self.max_depth = max_depth #The maximum depth of each decision tree.
        self.min_samples_split = min_samples_split #The minimum number of samples required to split a node.
        self.max_features = max_features #The number of features to consider when looking for the best split at each node.
        self.trees = []

    def bootstrap_sample(self, X, y):
        n_samples = X.shape[0]
        indices = np.random.choice(n_samples, n_samples, replace=True)
        return X.iloc[indices], y.iloc[indices]

    def fit(self, X, y):
        self.trees = []
        for i in range(self.n_estimators):
            print(f"Starting tree {i + 1} out of {self.n_estimators}...")  # Progress update
            start_time = time.time()
            X_sample, y_sample = self.bootstrap_sample(X, y)
            max_features = self.max_features or X.shape[1]
            features = np.random.choice(range(X.shape[1]), max_features, replace=False)

            # Subset X_sample to selected features
            X_sample_subset = X_sample.iloc[:, features]
            tree = DecisionTreeRegressor(max_depth=self.max_depth, min_samples_split=self.min_samples_split)
            print(f"Training tree {i + 1}...")  # Update during tree training
            tree.tree = tree.fit(X_sample_subset, y_sample)

            # Store the tree and the selected feature indices
            self.trees.append((tree, features))
            elapsed_time = time.time() - start_time  # Calculate elapsed time
            print(f"Finished tree {i + 1}. Time taken: {elapsed_time:.2f} seconds.")  # Completion update

    def predict(self, X):
        predictions = []
        for tree, features in self.trees:
            X_subset = X.iloc[:, features]
            predictions.append(tree.predict(X_subset))
        return np.mean(predictions, axis=0)
"""

# Performance Metrics
def rmse(y_true, y_pred):
    return np.sqrt(np.mean((y_true - y_pred) ** 2))

def mre(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / y_true))

def correlation(y_true, y_pred):
    return np.corrcoef(y_true, y_pred)[0, 1]

def r2(y_true, y_pred):
    return 1 - np.sum((y_true - y_pred) ** 2) / np.sum((y_true - np.mean(y_true)) ** 2)

def smape(y_true, y_pred):
    return 100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred)))

def cross_validate_with_kfold(model, X, y, k=5):
    """
    Perform k-fold cross-validation using sklearn's KFold.
    Args:
        model: The machine learning model to train.
        X: Features (pandas DataFrame).
        y: Targets (pandas Series).
        k: Number of folds.
    Returns:
        metrics: A dictionary with average performance metrics over the folds.
    """
    kf = KFold(n_splits=k, shuffle=True, random_state=42)
    metrics_list = []

    for fold, (train_index, val_index) in enumerate(kf.split(X), start=1):
        print(f"Starting Fold {fold}/{k}...")

        # Use iloc for pandas indexing
        X_train, X_val = X.iloc[train_index], X.iloc[val_index]
        y_train, y_val = y.iloc[train_index], y.iloc[val_index]

        # Train the model
        start_time = time.time()
        model.fit(X_train, y_train)
        end_time = time.time()

        print(f"Fold {fold} training completed in {end_time - start_time:.4f} seconds.")

        # Validate the model
        y_val_pred = model.predict(X_val)

        # Compute metrics for this fold
        fold_metrics = {
            'RMSE': rmse(y_val, y_val_pred),
            'MRE': mre(y_val, y_val_pred),
            'Correlation': correlation(y_val, y_val_pred),
            'R^2': r2(y_val, y_val_pred),
            'SMAPE': smape(y_val, y_val_pred)
        }
        metrics_list.append(fold_metrics)

    # Average the metrics over all folds
    avg_metrics = {key: np.mean([m[key] for m in metrics_list]) for key in metrics_list[0]}
    print("\nAverage Metrics Across All Folds:")
    for metric, value in avg_metrics.items():
        print(f"{metric}: {value:.4f}")
    return avg_metrics


class StreamToLogger:
    """
    A class that redirects the output of print statements to both the console and a log file.
    """

    def __init__(self, log_file):
        self.log_file = log_file
        self.console = sys.stdout  # Save the original stdout (console)

    def write(self, message):
        # Write the message to both the console and the log file
        if message != "\n":  # Avoid empty newline writes
            self.console.write(message)  # Print to the console
            if self.log_file and not self.log_file.closed:
                self.log_file.write(message)  # Write to the log file
        else:
            # Ensure that newline characters are also written properly
            self.console.write("\n")
            if self.log_file and not self.log_file.closed:
                self.log_file.write("\n")

    def flush(self):
        # This is needed for Python 3 compatibility
        self.console.flush()
        if self.log_file and not self.log_file.closed:
            self.log_file.flush()

    def close(self):
        # Close the log file safely
        if self.log_file and not self.log_file.closed:
            self.log_file.close()


# Step 5: Test the implementation
if __name__ == "__main__":
    os.chdir("C:/Users/ameli/OneDrive/Studium/TU Wien/WS2024/ML/Exercise 2")

    import sys
    log_file = open("ML_Ex2_LLM_withParallelization.txt", "w")
    sys.stdout = StreamToLogger(log_file)

    """
    ##### CT DATASET #####
    ### WITHOUT CROSS VALIDATION ###
    CT_train = pd.read_csv("CT_train.csv")
    CT_test = pd.read_csv("CT_test.csv")
    # Split data into features and targets
    X_train = CT_train.drop(columns='critical_temp')
    y_train = CT_train['critical_temp']
    X_test = CT_test.drop(columns='critical_temp')
    y_test = CT_test['critical_temp']
    # Train the Random Forest Regressor
    start = time.time()
    rf = RandomForestRegressor(n_estimators=5)
    rf.fit(X_train, y_train)
    end = time.time()
    print(f"Total Time to Train Random Forest: {end - start:.4f} seconds")
    # Make predictions
    y_pred = rf.predict(X_test)
    # Evaluate the model using custom performance metrics
    print("Performance Metrics:")
    print(f"Root Mean Squared Error (RMSE): {rmse(y_test, y_pred):.4f}")
    print(f"Mean Relative Error (MRE): {mre(y_test, y_pred):.4f}")
    print(f"Correlation: {correlation(y_test, y_pred):.4f}")
    print(f"R^2 Score: {r2(y_test, y_pred):.4f}")
    print(f"SMAPE: {smape(y_test, y_pred):.4f}")

    ### WITH CROSS VALIDATION ###
    start = time.time()
    rf = RandomForestRegressor(n_estimators=10, max_depth=5)
    k = 5
    print(f"Performing {k}-Fold Cross-Validation...")
    avg_metrics = cross_validate_with_kfold(rf, X_train, y_train, k=k)
    print(avg_metrics)
    end = time.time()
    print(f"Total Time for Cross-Validation: {end - start:.4f} seconds")
    """

    ##### MPG DATASET #####
    ### WITHOUT CROSS VALIDATION ###
    MPG_train = pd.read_csv("MPG_train.csv")
    MPG_test = pd.read_csv("MPG_test.csv")
    X_train = MPG_train.drop(columns='mpg')
    y_train = MPG_train['mpg']
    X_test = MPG_test.drop(columns='mpg')
    y_test = MPG_test['mpg']
    start = time.time()
    rf = RandomForestRegressor()
    rf.fit(X_train, y_train)
    end = time.time()
    print(f"Total Time to Train Random Forest: {end - start:.4f} seconds")
    y_pred = rf.predict(X_test)
    # Make predictions
    y_pred = rf.predict(X_test)
    # Evaluate the model using custom performance metrics
    print("Performance Metrics:")
    print(f"Root Mean Squared Error (RMSE): {rmse(y_test, y_pred):.4f}")
    print(f"Mean Relative Error (MRE): {mre(y_test, y_pred):.4f}")
    print(f"Correlation: {correlation(y_test, y_pred):.4f}")
    print(f"R^2 Score: {r2(y_test, y_pred):.4f}")
    print(f"SMAPE: {smape(y_test, y_pred):.4f}")

    ### WITH CROSS VALIDATION ###
    start = time.time()
    rf = RandomForestRegressor(n_estimators=10, max_depth=5)
    k = 5
    print(f"Performing {k}-Fold Cross-Validation...")
    avg_metrics = cross_validate_with_kfold(rf, X_train, y_train, k=k)
    print(avg_metrics)
    end = time.time()
    print(f"Total Time for Cross-Validation: {end - start:.4f} seconds")

    sys.stdout.close()