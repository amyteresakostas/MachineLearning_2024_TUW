import os
import time
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import numpy as np
from sklearn.model_selection import cross_validate
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import make_scorer, mean_squared_error
import sys
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer, root_mean_squared_error, r2_score

def rmse(y_true, y_pred):
    return (np.sqrt(np.mean((y_true - y_pred) ** 2)))
def mre(y_true, y_pred):
    return (np.mean(np.abs((y_true - y_pred) / y_true)))
def correlation(y_true, y_pred):
    return np.corrcoef(y_true, y_pred)[0, 1]
def r2(y_true, y_pred):
    return 1 - np.sum((y_true - y_pred) ** 2) / np.sum((y_true - np.mean(y_true)) ** 2)
def smape(y_true, y_pred):
    return (100 * np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred))))

def holdout_model(model, X_train, y_train, X_test, y_test, title, save_path=None):
    start_fit = time.time()
    model.fit(X_train, y_train)
    end_fit = time.time()
    start_pred = time.time()
    y_pred = model.predict(X_test)
    end_pred = time.time()

    mse_val = mean_squared_error(y_test, y_pred)
    r2_val = r2_score(y_test, y_pred)
    smape_val = smape(y_test, y_pred)
    mre_val = mre(y_test, y_pred)
    corr_val = correlation(y_test, y_pred)
    print("Fitting time: ", end_fit-start_fit)
    print("Prediction time: ", end_pred - start_pred)
    print("MSE: ", mse_val)
    print("R squared: ", r2_val)
    print("Smape: ", smape_val)
    print("MRE: ", mre_val)
    print("Correlation: ", corr_val)

    if save_path:
        plt.scatter(y_test, y_pred, color='red')
        plt.title(title)
        plt.xlabel('true')
        plt.ylabel('predicted')
        #plt.show()
        plt.savefig(save_path, bbox_inches="tight")

    return mse_val, smape_val, r2_val, corr_val, mre_val

def cross_validate_model(model, X, y, cv, printer = True):
    scoring = {
        'rmse': make_scorer(rmse, greater_is_better=False),
        'r2': make_scorer(r2),
        'smape': make_scorer(smape, greater_is_better=False),
        'mre': make_scorer(mre, greater_is_better=False),
        'corr': make_scorer(correlation)
    }

    start = time.time()
    cv_results = cross_validate(model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
    end = time.time()

    if printer == True:
        print("Crossvalidation Time:", end-start)
        print("SMAPE:", -np.mean(cv_results['test_smape']))
        print("RMSE:", -np.mean(cv_results['test_rmse']))
        print("R²:", np.mean(cv_results['test_r2']))
        print("Correlation:", np.mean(cv_results['test_corr']))
        print("MRE:", -np.mean(cv_results['test_mre']))

    return cv_results

def find_optimal_max_depth(max_depth, X_train, y_train, cv):
    r2_scores = []
    start_k = time.time()
    for depth in max_depth:
        rf = RandomForestRegressor(max_depth=depth, random_state=42, n_jobs=-1)
        cv_results = cross_validate_model(rf, X_train, y_train, cv=cv, printer=False)
        r2_scores.append(cv_results['test_r2'].mean())
    end_k = time.time()
    optimal_max_depth = max_depth[np.argmax(r2_scores)]
    print("Optimal maximum depth:", optimal_max_depth)
    print("Time: ", {end_k - start_k})
    return r2_scores

def find_optimal_n_estimator(n_estimator, X_train, y_train, cv):
    r2_scores = []
    start_k = time.time()
    for estimator in n_estimator:
        rf = RandomForestRegressor(n_estimators=estimator, random_state=42, n_jobs=-1)
        cv_results = cross_validate_model(rf, X_train, y_train, cv=cv, printer=False)
        r2_scores.append(cv_results['test_r2'].mean())
    end_k = time.time()
    optimal_n_estimator = n_estimator[np.argmax(r2_scores)]
    print("Optimal number of estimators:", optimal_n_estimator)
    print("Time: ", {end_k - start_k})
    return r2_scores

def find_optimal_min_samples_split(min_samples_split, X_train, y_train, cv):
    r2_scores = []
    start_k = time.time()
    for split in min_samples_split:
        rf = RandomForestRegressor(min_samples_leaf=split, random_state=42, n_jobs=-1)
        cv_results = cross_validate_model(rf, X_train, y_train, cv=cv, printer=False)
        r2_scores.append(cv_results['test_r2'].mean())
    end_k = time.time()
    optimal_min_samples_split = min_samples_split[np.argmax(r2_scores)]
    print("Optimal number of minimum samples split:", optimal_min_samples_split)
    print("Time: ", {end_k - start_k})
    return r2_scores

########################################################################################################################
########################################################################################################################

os.chdir("C:/Users/ameli/OneDrive/Studium/TU Wien/WS2024/ML/Exercise 2")
os.makedirs("plot", exist_ok=True)

#log_file = open("ML_Ex2_Existing_RF_performanceMeasures.txt", "w")
#sys.stdout = log_file

print("------------------------------------")
print("MPG Dataset")
MPG_train = pd.read_csv("MPG_train.csv")
MPG_test = pd.read_csv("MPG_test.csv")
X_train_MPG = MPG_train.drop('mpg', axis=1); y_train_MPG = MPG_train['mpg']
X_test_MPG = MPG_test.drop('mpg', axis=1); y_test_MPG = MPG_test['mpg']
print("----------------------------------------------------------------------------------------------")
print("MPG - With CV, Without Scaling:")
rf = RandomForestRegressor(random_state=42, n_jobs=-1)
cross_validate_model(rf, X_train_MPG, y_train_MPG, 5)
# Hyperparameter tuning (finding the best parameter combinations)
print("----------------------------------------------------------------------------------------------")
print("Hyperparameter tuning (finding best parameter combinations):")
param_grid = {
        'n_estimators': [30, 50],
        'max_depth': [10, 20],
        'min_samples_split': [5, 15],
        'max_features': [int(np.sqrt(X_train_MPG.shape[1])), int(np.log(X_train_MPG.shape[1]))]
    }
scoring = {
        "rmse": make_scorer(root_mean_squared_error, greater_is_better=False),
        "r2": make_scorer(r2_score),
        "smape": make_scorer(smape, greater_is_better=False),
        "correlation": make_scorer(correlation)
}
start = time.time()
rf = RandomForestRegressor()
grid_search = GridSearchCV(rf, param_grid, cv=5, scoring=scoring, refit='rmse', n_jobs=-1)
grid_search.fit(X_train_MPG, y_train_MPG)
print(f"Best parameters: {grid_search.best_params_}")
print(f"Best cross-validation rmse: {grid_search.cv_results_['mean_test_rmse'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation r2: {grid_search.cv_results_['mean_test_r2'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation smape: {grid_search.cv_results_['mean_test_smape'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation correlation: {grid_search.cv_results_['mean_test_correlation'][grid_search.best_index_]:.4f}")
print("Time for Hypertuning: ", time.time()-start)
### Predict with best parameters on Test set ###
print("----------------------------------------------------------------------------------------------")
print("MPG Testset:")
best_model_MPG = RandomForestRegressor(**grid_search.best_params_)
start = time.time()
best_model_MPG.fit(X_train_MPG, y_train_MPG)
end = time.time()
y_pred_MPG = best_model_MPG.predict(X_test_MPG)
print("RMSE for MPG on Test Set:", root_mean_squared_error(y_test_MPG, y_pred_MPG))
print("SMAPE for MPG on Test Set:", smape(y_test_MPG, y_pred_MPG))
print("CORRELATION for MPG on Test Set:", correlation(y_test_MPG, y_pred_MPG))
print("R2 for MPG on Test Set:", r2(y_test_MPG, y_pred_MPG))
print("Time:", end-start)


########################################################################################################################
########################################################################################################################
print("")
print("")
print("")
print("------------------------------------")
print("CT Dataset")
CT_train = pd.read_csv("CT_train.csv")
CT_test = pd.read_csv("CT_test.csv")
X_train_CT = CT_train.drop('critical_temp', axis=1); y_train_CT = CT_train['critical_temp']
X_test_CT = CT_test.drop('critical_temp', axis=1); y_test_CT = CT_test['critical_temp']

print("----------------------------------------------------------------------------------------------")
print("CT - With CV, Without Scaling:")
rf = RandomForestRegressor(random_state=42, n_jobs=-1)
cross_validate_model(rf, X_train_CT, y_train_CT, 5)
# Hyperparameter tuning (finding the best parameter combinations)
print("----------------------------------------------------------------------------------------------")
print("Hyperparameter tuning (finding best parameter combinations):")
param_grid = {
        'n_estimators': [30, 50],
        'max_depth': [10, 20],
        'min_samples_split': [5, 15],
        'max_features': [int(np.sqrt(X_train_CT.shape[1])), int(np.log(X_train_CT.shape[1]))]
    }
scoring = {
        "rmse": make_scorer(root_mean_squared_error, greater_is_better=False),
        "r2": make_scorer(r2_score),
        "smape": make_scorer(smape, greater_is_better=False),
        "correlation": make_scorer(correlation)
}
start = time.time()
rf = RandomForestRegressor()
grid_search = GridSearchCV(rf, param_grid, cv=4, scoring=scoring, refit='rmse', n_jobs=-1)
grid_search.fit(X_train_CT, y_train_CT)
print(f"Best parameters: {grid_search.best_params_}")
print(f"Best cross-validation rmse: {grid_search.cv_results_['mean_test_rmse'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation r2: {grid_search.cv_results_['mean_test_r2'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation smape: {grid_search.cv_results_['mean_test_smape'][grid_search.best_index_]:.4f}")
print(f"Best cross-validation correlation: {grid_search.cv_results_['mean_test_correlation'][grid_search.best_index_]:.4f}")
print("Time for Hypertuning: ", time.time()-start)
### Predict with best parameters on Test set ###
print("----------------------------------------------------------------------------------------------")
print("CT Testset:")
best_model_CT = RandomForestRegressor(**grid_search.best_params_)
start = time.time()
best_model_CT.fit(X_train_CT, y_train_CT)
end = time.time()
y_pred_CT = best_model_CT.predict(X_test_CT)
print("RMSE for CT on Test Set:", root_mean_squared_error(y_test_CT, y_pred_CT))
print("SMAPE for CT on Test Set:", smape(y_test_CT, y_pred_CT))
print("CORRELATION for CT on Test Set:", correlation(y_test_CT, y_pred_CT))
print("R2 for CT on Test Set:", r2(y_test_CT, y_pred_CT))
print("Time:", end-start)